package Model;

public class Product {
    private int pid;
    private String name;
    private String brand;

    public Product(int pid, String name, String brand) {
        this.pid = pid;
        this.name = name;
        this.brand = brand;
    }

    public int getPid() {
        return pid;
    }

    public String getName() {
        return name;
    }

    public String getBrand() {
        return brand;
    }
}
