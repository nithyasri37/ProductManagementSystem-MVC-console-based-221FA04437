package Controller;

import Model.Product;
import View.ProductView;

public class ProductController {
    private Product model;
    private ProductView view;

    public ProductController(Product model, ProductView view) {
        this.model = model;
        this.view = view;
    }

    public void displayProduct() {
        view.print(model.getPid(), model.getName(), model.getBrand());
    }
}
