package Main;

import Controller.ProductController;
import Model.Product;
import View.ProductView;

public class Main {
    public static void main(String[] args) {
        Product model = new Product(3066, "Reehu", "CSE");
        ProductView view = new ProductView();
        ProductController controller = new ProductController(model, view);
        
        controller.displayProduct();
        
    }
}
