package View;

public class ProductView {
	public void print(int pid,String name,String Brand) {
		System.out.println("ProductDetails:");
		System.out.println("ProductId:"+pid);
		System.out.println("ProductName:"+name);
		System.out.println("ProductBrand:"+Brand);
	}

}
